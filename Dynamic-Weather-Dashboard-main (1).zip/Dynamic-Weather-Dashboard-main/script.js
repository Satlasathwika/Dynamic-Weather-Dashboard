document.addEventListener('DOMContentLoaded', () => {
  // Landing page transition
  const landingPage = document.getElementById('landing-page');
  const mainContent = document.getElementById('main-content');
  const continueBtn = document.getElementById('continue-btn');
  const recentSearchesSection = document.getElementById('recent-searches');
  const footer = document.getElementById('footer');
  const loadingSpinner = document.getElementById('loading-spinner');

  // Show main content when Continue button is clicked
  continueBtn.addEventListener('click', () => {
    // Fade out landing page
    landingPage.classList.add('fade-out');
    
    // Show main content
    mainContent.classList.remove('hidden');
    recentSearchesSection.classList.remove('hidden');
    footer.classList.remove('hidden');
    
    // After a short delay, fade in the main content
    setTimeout(() => {
      mainContent.classList.add('fade-in');
      recentSearchesSection.classList.add('visible');
      footer.classList.add('visible');
      
      // Check if we have any stored recent cities
      displayRecentCities();
    }, 100);
  });
  
  const cityInput = document.querySelector(".city-input");
  const searchButton = document.querySelector(".search-btn");
  const locationButton = document.querySelector(".location-btn");
  const currentWeatherDiv = document.querySelector(".current-weather");
  const weatherCardsDiv = document.querySelector(".weather-cards");
  const recentCitiesDiv = document.getElementById("recent-cities");
  const unitButtons = document.querySelectorAll(".unit-btn");
  
  const API_KEY = "ff0c94e8259c8e9a8f87af42a89d4a0c";
  
  // Set default temperature unit
  let temperatureUnit = "celsius";
  
  // Unit toggle functionality
  unitButtons.forEach(button => {
    button.addEventListener('click', () => {
      // If the button is already active, don't do anything
      if (button.classList.contains('active')) return;
      
      // Remove active class from all buttons
      unitButtons.forEach(btn => btn.classList.remove('active'));
      
      // Add active class to clicked button
      button.classList.add('active');
      
      // Set the new temperature unit
      temperatureUnit = button.getAttribute('data-unit');
      
      // Update displayed temperatures
      updateTemperatures();
    });
  });
  
  // Function to convert Kelvin to Celsius or Fahrenheit
  const convertTemperature = (kelvin) => {
    if (temperatureUnit === "celsius") {
      return (kelvin - 273.15).toFixed(1) + "°C";
    } else {
      return (((kelvin - 273.15) * 9/5) + 32).toFixed(1) + "°F";
    }
  };
  
  // Function to update temperatures based on selected unit
  const updateTemperatures = () => {
    // Update current weather temperatures
    const currentTempElements = document.querySelectorAll('.current-weather .temp-value, .current-weather .feels-like-value');
    
    currentTempElements.forEach(element => {
      const kelvinMatch = element.getAttribute('data-kelvin');
      if (kelvinMatch) {
        if (element.classList.contains('temp-value')) {
          element.textContent = convertTemperature(parseFloat(kelvinMatch));
        } else {
          element.textContent = "Feels like: " + convertTemperature(parseFloat(kelvinMatch));
        }
      }
    });
    
    // Update forecast card temperatures
    const forecastTempElements = document.querySelectorAll('.weather-card .card-stat span:not(.stat-icon)');
    forecastTempElements.forEach(element => {
      const kelvinMatch = element.getAttribute('data-kelvin');
      if (kelvinMatch) {
        if (element.classList.contains('main-temp')) {
          element.textContent = convertTemperature(parseFloat(kelvinMatch));
        } else if (element.classList.contains('feels-temp')) {
          element.textContent = "Feels: " + convertTemperature(parseFloat(kelvinMatch));
        }
      }
    });
  };
  
  // Save city to recent searches
  const saveToRecentCities = (cityName) => {
    let recentCities = JSON.parse(localStorage.getItem('recentCities')) || [];
    
    // Remove the city if it's already in the list
    recentCities = recentCities.filter(city => city.toLowerCase() !== cityName.toLowerCase());
    
    // Add the city to the beginning of the array
    recentCities.unshift(cityName);
    
    // Keep only the latest 5 cities
    recentCities = recentCities.slice(0, 5);
    
    // Save to localStorage
    localStorage.setItem('recentCities', JSON.stringify(recentCities));
    
    // Update the display
    displayRecentCities();
  };
  
  // Display recent cities
  const displayRecentCities = () => {
    const recentCities = JSON.parse(localStorage.getItem('recentCities')) || [];
    const recentCitiesDiv = document.getElementById('recent-cities');
    
    if (recentCitiesDiv) {
      // Clear existing content
      recentCitiesDiv.innerHTML = '';
      
      if (recentCities.length > 0) {
        document.getElementById('recent-searches').classList.add('visible');
        
        // Add city chips
        recentCities.forEach(city => {
          const cityChip = document.createElement('div');
          cityChip.className = 'city-chip';
          cityChip.innerHTML = `
            ${city}
            <span class="remove-city" data-city="${city}"></span>
          `;
          
          cityChip.addEventListener('click', (e) => {
            if (!e.target.classList.contains('remove-city')) {
              cityInput.value = city;
              getCityCoordinates();
            }
          });
          
          recentCitiesDiv.appendChild(cityChip);
        });
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-city').forEach(button => {
          button.addEventListener('click', (e) => {
            e.stopPropagation();
            const cityToRemove = button.getAttribute('data-city');
            removeFromRecentCities(cityToRemove);
          });
        });
      } else {
        document.getElementById('recent-searches').classList.remove('visible');
      }
    }
  };
  
  // Remove a city from recent searches
  const removeFromRecentCities = (cityName) => {
    let recentCities = JSON.parse(localStorage.getItem('recentCities')) || [];
    
    // Filter out the city to remove
    recentCities = recentCities.filter(city => city !== cityName);
    
    // Save to localStorage
    localStorage.setItem('recentCities', JSON.stringify(recentCities));
    
    // Update the display
    displayRecentCities();
  };
  
  // Function to get weather icon HTML
  const getWeatherIconHTML = (iconCode, size = 'large') => {
    const iconSizeClass = size === 'large' ? 'h-16 w-16' : 'h-10 w-10';
    
    return `<img src="https://openweathermap.org/img/wn/${iconCode}@${size === 'large' ? '4' : '2'}x.png" alt="Weather Icon" class="animate-float">`;
  };
  
  // Create current weather HTML
  const createCurrentWeatherHTML = (cityName, weatherItem) => {
    const date = new Date(weatherItem.dt_txt);
    const formattedDate = date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const iconHTML = getWeatherIconHTML(weatherItem.weather[0].icon);
    
    return `
      <div class="details">
        <h2 class="city-name">${cityName}</h2>
        <p class="date">${formattedDate}</p>
        
        <div class="weather-stats">
          <div class="weather-stat">
            <span class="temp-icon"></span>
            <span class="temp-value" data-kelvin="${weatherItem.main.temp}">${convertTemperature(weatherItem.main.temp)}</span>
          </div>
          
          <div class="weather-stat">
            <span class="feels-like-icon"></span>
            <span class="feels-like-value" data-kelvin="${weatherItem.main.feels_like}">Feels like: ${convertTemperature(weatherItem.main.feels_like)}</span>
          </div>
          
          <div class="weather-stat">
            <span class="wind-icon"></span>
            <span class="wind-value">${weatherItem.wind.speed} m/s</span>
          </div>
          
          <div class="weather-stat">
            <span class="humidity-icon"></span>
            <span class="humidity-value">${weatherItem.main.humidity}%</span>
          </div>
        </div>
      </div>
      
      <div class="weather-icon">
        <div class="icon-placeholder">
          ${iconHTML}
        </div>
        <p class="weather-description">${weatherItem.weather[0].description}</p>
      </div>
    `;
  };
  
  // Create forecast card HTML
  const createForecastCardHTML = (weatherItem) => {
    const date = new Date(weatherItem.dt_txt);
    const formattedDate = date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    const iconHTML = getWeatherIconHTML(weatherItem.weather[0].icon, 'small');
    
    return `
      <div class="weather-card">
        <h3>${formattedDate}</h3>
        
        <div class="card-icon">
          ${iconHTML}
        </div>
        
        <p class="card-description">${weatherItem.weather[0].description}</p>
        
        <div class="card-stats">
          <div class="card-stat">
            <span class="stat-icon temp-icon"></span>
            <span class="main-temp" data-kelvin="${weatherItem.main.temp}">${convertTemperature(weatherItem.main.temp)}</span>
          </div>
          
          <div class="card-stat">
            <span class="stat-icon feels-like-icon"></span>
            <span class="feels-temp" data-kelvin="${weatherItem.main.feels_like}">Feels: ${convertTemperature(weatherItem.main.feels_like)}</span>
          </div>
          
          <div class="card-stat">
            <span class="stat-icon wind-icon"></span>
            <span>${weatherItem.wind.speed} m/s</span>
          </div>
          
          <div class="card-stat">
            <span class="stat-icon humidity-icon"></span>
            <span>${weatherItem.main.humidity}%</span>
          </div>
        </div>
      </div>
    `;
  };
  
  // Show loading spinner
  const showLoadingSpinner = () => {
    loadingSpinner.classList.add('active');
  };
  
  // Hide loading spinner
  const hideLoadingSpinner = () => {
    loadingSpinner.classList.remove('active');
  };
  
  // Get weather details from coordinates
  const getWeatherDetails = (cityName, lat, lon) => {
    showLoadingSpinner();
    
    const WEATHER_API_URL = `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${API_KEY}`;
    
    fetch(WEATHER_API_URL)
      .then(res => res.json())
      .then(data => {
        // Filter forecasts to get one per day
        const uniqueForecastDays = [];
        const fiveDaysForecast = data.list.filter(forecast => {
          const forecastDate = new Date(forecast.dt_txt).getDate();
          if (!uniqueForecastDays.includes(forecastDate)) {
            return uniqueForecastDays.push(forecastDate);
          }
          return false;
        });
        
        // Clear previous weather data
        cityInput.value = "";
        weatherCardsDiv.innerHTML = "";
        
        // Update current weather
        currentWeatherDiv.innerHTML = createCurrentWeatherHTML(cityName, fiveDaysForecast[0]);
        
        // Create forecast cards
        fiveDaysForecast.slice(1).forEach(weatherItem => {
          weatherCardsDiv.innerHTML += createForecastCardHTML(weatherItem);
        });
        
        // Save the city to recent searches
        saveToRecentCities(cityName);
        
        // Update URL for bookmarking
        updateURLWithCity(cityName);
        
        hideLoadingSpinner();
      })
      .catch(() => {
        showError("An error occurred while fetching the weather forecast!");
        hideLoadingSpinner();
      });
  };
  
  // Update URL with city parameter for bookmarking
  const updateURLWithCity = (city) => {
    if (history.pushState) {
      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set('city', city);
      window.history.pushState({ path: newUrl.href }, '', newUrl.href);
    }
  };
  
  // Get city coordinates from name
  const getCityCoordinates = () => {
    const cityName = cityInput.value.trim();
    if (!cityName) {
      showError("Please enter a city name!");
      return;
    }
    
    showLoadingSpinner();
    showLoadingState();
    
    const GEOCODING_API_URL = `https://api.openweathermap.org/geo/1.0/direct?q=${cityName}&limit=1&appid=${API_KEY}`;
    
    fetch(GEOCODING_API_URL)
      .then(res => res.json())
      .then(data => {
        if (!data.length) {
          showError(`No coordinates found for ${cityName}`);
          hideLoadingSpinner();
          hideLoadingState();
          return;
        }
        
        const { name, lat, lon } = data[0];
        getWeatherDetails(name, lat, lon);
      })
      .catch(() => {
        showError("An error occurred while fetching coordinates!");
        hideLoadingSpinner();
        hideLoadingState();
      });
  };
  
  // Get user's current location coordinates
  const getUserCoordinates = () => {
    if (navigator.geolocation) {
      showLoadingSpinner();
      showLoadingState();
      
      navigator.geolocation.getCurrentPosition(
        position => {
          const { latitude, longitude } = position.coords;
          const REVERSE_GEOCODING_URL = `https://api.openweathermap.org/geo/1.0/reverse?lat=${latitude}&lon=${longitude}&limit=1&appid=${API_KEY}`;
          
          fetch(REVERSE_GEOCODING_URL)
            .then(res => res.json())
            .then(data => {
              const { name } = data[0];
              getWeatherDetails(name, latitude, longitude);
            })
            .catch(() => {
              showError("An error occurred while fetching the city!");
              hideLoadingSpinner();
              hideLoadingState();
            });
        },
        error => {
          if (error.code === error.PERMISSION_DENIED) {
            showError("Geolocation request denied. Please allow location access.");
          }
          hideLoadingSpinner();
          hideLoadingState();
        }
      );
    } else {
      showError("Geolocation is not supported by this browser!");
    }
  };
  
  // Show loading state
  const showLoadingState = () => {
    searchButton.disabled = true;
    locationButton.disabled = true;
    searchButton.textContent = "Searching...";
    locationButton.textContent = "Locating...";
  };
  
  // Hide loading state
  const hideLoadingState = () => {
    searchButton.disabled = false;
    locationButton.disabled = false;
    searchButton.innerHTML = '<span class="search-icon-small"></span>Search';
    locationButton.innerHTML = '<span class="location-icon"></span>Use Current Location';
  };
  
  // Show error toast message
  const showError = (message) => {
    // Remove any existing error toast
    const existingToast = document.querySelector('.error-toast');
    if (existingToast) {
      document.body.removeChild(existingToast);
    }
    
    const toast = document.createElement("div");
    toast.className = "error-toast";
    toast.textContent = message;
    document.body.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
      if (toast.parentNode) {
        document.body.removeChild(toast);
      }
    }, 3000);
  };
  
  // Event listeners
  searchButton.addEventListener("click", getCityCoordinates);
  locationButton.addEventListener("click", getUserCoordinates);
  cityInput.addEventListener("keyup", e => {
    if (e.key === "Enter") {
      getCityCoordinates();
    }
  });
  
  // Initialize with placeholder state
  currentWeatherDiv.innerHTML = `
    <div class="details">
      <h2 class="city-name">________ (______________)</h2>
      <div class="weather-stats">
        <div class="weather-stat">
          <span class="temp-icon"></span>
          <span class="temp-value">____°C</span>
        </div>
        
        <div class="weather-stat">
          <span class="feels-like-icon"></span>
          <span class="feels-like-value">Feels like: ____°C</span>
        </div>
        
        <div class="weather-stat">
          <span class="wind-icon"></span>
          <span class="wind-value">____ m/s</span>
        </div>
        
        <div class="weather-stat">
          <span class="humidity-icon"></span>
          <span class="humidity-value">___%</span>
        </div>
      </div>
    </div>
    <div class="weather-icon">
      <div class="icon-placeholder"></div>
      <p class="weather-description"></p>
    </div>
  `;
  
  weatherCardsDiv.innerHTML = `
    <div class="weather-card">
      <h3>(______________)</h3>
      <div class="card-icon"></div>
      <p class="card-description"></p>
      <div class="card-stats">
        <div class="card-stat">
          <span class="stat-icon temp-icon"></span>
          <span>____°C</span>
        </div>
        <div class="card-stat">
          <span class="stat-icon feels-like-icon"></span>
          <span>Feels: ____°C</span>
        </div>
        <div class="card-stat">
          <span class="stat-icon wind-icon"></span>
          <span>____ m/s</span>
        </div>
        <div class="card-stat">
          <span class="stat-icon humidity-icon"></span>
          <span>___%</span>
        </div>
      </div>
    </div>
  `.repeat(4);
  
  // Check if a city is provided in URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const cityParam = urlParams.get('city');
  
  // If we're not on the landing page and a city parameter exists
  if (cityParam && !landingPage.classList.contains('fade-out')) {
    // Skip the landing page
    landingPage.classList.add('fade-out');
    mainContent.classList.remove('hidden');
    recentSearchesSection.classList.remove('hidden');
    footer.classList.remove('hidden');
    
    setTimeout(() => {
      mainContent.classList.add('fade-in');
      recentSearchesSection.classList.add('visible');
      footer.classList.add('visible');
      
      // Search for the city from the URL
      cityInput.value = cityParam;
      getCityCoordinates();
      
      // Display recent cities
      displayRecentCities();
    }, 100);
  }
});
