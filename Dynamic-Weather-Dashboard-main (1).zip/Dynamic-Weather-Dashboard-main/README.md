The Dynamic Weather Dashboard is a simple yet powerful web application built with HTML, CSS, and JavaScript. It provides real-time weather updates by fetching data from an external weather API such as OpenWeatherMap
. Designed to be responsive and user-friendly, this project demonstrates how to integrate APIs into a front-end application while keeping the UI clean and interactive.

🚀 Features
Search Weather by City – Enter any city to view current weather details.
Geolocation Support – Automatically detects and displays weather for the user’s current location.
Real-Time Data – Displays temperature, humidity, wind speed, and weather conditions.
Dynamic Interface – Icons and background visuals adjust based on live weather.
Responsive Design – Works seamlessly across desktops, tablets, and mobile devices.

🛠️ Tech Stack
HTML5 – Application structure
CSS3 – Styling and responsive layouts
JavaScript (ES6+) – API calls and DOM manipulation
Weather API – Fetches live weather information
